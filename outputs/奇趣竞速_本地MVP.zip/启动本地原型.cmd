@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "RACE_NODE=node"
where node >nul 2>nul
if errorlevel 1 set "RACE_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
echo 本地试玩地址：http://127.0.0.1:3100
echo 请在浏览器打开以上地址。此窗口关闭后，本地服务停止。
"%RACE_NODE%" server.mjs
pause
